package com.thea.labdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class EditFoodActivity extends AppCompatActivity {

    EditText etName, etPrice;
    TextView tvSubmit;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        etName = (EditText) findViewById(R.id.etEditFoodName);
        etPrice = (EditText) findViewById(R.id.etEditPrice);
        tvSubmit = (TextView) findViewById(R.id.tvEditSubmit);

        tvSubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String name = etName.getText().toString();
                double price = Double.parseDouble(etPrice.getText().toString());
                Food f = new Food(name, price);
                //add food to db
                long id = new DatabaseHelper(getBaseContext()).createFood(f);

                Log.i("huh", "zzzz");
                if(id == -1){
                    //

                }
                else{
                    finish();
                }
            }
        });
    }
}
