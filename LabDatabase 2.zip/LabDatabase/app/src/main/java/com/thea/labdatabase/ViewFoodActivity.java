package com.thea.labdatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ViewFoodActivity extends AppCompatActivity {
    TextView tvId, tvName, tvPrice;
    DatabaseHelper dbHelper;
    Button btnEdit, btnDelete;
    int id = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_food);

        tvId = (TextView) findViewById(R.id.tv_id);
        tvName = (TextView) findViewById(R.id.tv_name);
        tvPrice = (TextView) findViewById(R.id.tv_price);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnDelete = (Button) findViewById(R.id.btnDelete);

        id = getIntent().getIntExtra(Food.COLUMN_ID, -1);
        if(id != -1){
            dbHelper = new DatabaseHelper(getBaseContext());
            Food food = dbHelper.getFood(id);
            Log.i("food id: ", food.getId() + "");
            Log.i("food name: ", food.getName() + "");
            Log.i("food price: ", food.getPrice() + "");

            tvId.setText(food.getId() + "");
            tvName.setText(food.getName());
            tvPrice.setText(food.getPrice() + "");
        }

        btnDelete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //add food to db
                dbHelper.deleteFood(id);
                finish();
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //add food to db
                Intent i = new Intent(getBaseContext(), EditFoodActivity.class);
                i.putExtra(Food.COLUMN_ID, id);
                startActivity(i);
                finish();
            }
        });
    }
}
