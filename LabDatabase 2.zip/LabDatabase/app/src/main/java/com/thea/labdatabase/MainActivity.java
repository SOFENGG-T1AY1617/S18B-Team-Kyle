package com.thea.labdatabase;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvFood;
    TextView tvAdd;
    FoodAdapter foodAdapter;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvFood = (RecyclerView) findViewById(R.id.rv_food);
        tvAdd = (TextView) findViewById(R.id.tv_add);

        dbHelper = new DatabaseHelper(getBaseContext());

        Cursor c = dbHelper.getAllFood();
        foodAdapter = new FoodAdapter(getBaseContext(), c);

        foodAdapter.setOnItemClickListener(new FoodAdapter.onItemClickListener(){
            @Override
            public void onItemClick(int id){
                //database id of the food object
                //go to ViewFoodActivity

                Intent i = new Intent(getBaseContext(), ViewFoodActivity.class);
                i.putExtra(Food.COLUMN_ID, id);
                startActivity(i);
            }
        });


        rvFood.setAdapter(foodAdapter);
        rvFood.setLayoutManager(new LinearLayoutManager(getBaseContext(), LinearLayoutManager.VERTICAL, false));

        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), AddFoodActivity.class);
                startActivity(i);

            }
        });
    }

    @Override
    protected void onResume(){
        super.onResume();
        //populate the content of RecyclerView

        Cursor c = dbHelper.getAllFood();
        //changeCursor will close the oldCursor for you
        foodAdapter.changeCursor(c);
    }
}
