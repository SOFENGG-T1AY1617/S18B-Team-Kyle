package com.thea.labdatabase;

import android.content.Context;
import android.database.Cursor;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by Thea on 06/03/2017.
 */

public class FoodAdapter extends CursorRecyclerViewAdapter<FoodAdapter.FoodViewHolder> {


    public FoodAdapter(Context context, Cursor cursor) {
        super(context, cursor);
    }

    @Override
    public void onBindViewHolder(FoodViewHolder viewHolder, Cursor cursor) {
        //cursor already points to the current position

        int id = cursor.getInt(cursor.getColumnIndex(Food.COLUMN_ID));
        String name = cursor.getString(cursor.getColumnIndex(Food.COLUMN_NAME));
        double price = cursor.getDouble(cursor.getColumnIndex(Food.COLUMN_PRICE));
        Food food = new Food(id, name, price);

        viewHolder.tvName.setText(food.getName());
        viewHolder.tvName.setTag(id);

        viewHolder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onItemClickListener != null){
                    int id = (int) v.getTag();
                    onItemClickListener.onItemClick(id);
                }
            }
        });

    }

    @Override
    public FoodViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_food, parent, false);

        return new FoodViewHolder(v);
    }

    public class FoodViewHolder extends RecyclerView.ViewHolder{
        TextView tvName;
        public FoodViewHolder(View itemView){
            super(itemView);
            tvName = (TextView) itemView.findViewById(R.id.tv_name);
        }
    }

    private onItemClickListener onItemClickListener;

    public void setOnItemClickListener(onItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface onItemClickListener{
        public void onItemClick(int id);
    }


}
