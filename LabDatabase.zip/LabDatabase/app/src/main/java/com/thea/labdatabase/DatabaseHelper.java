package com.thea.labdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Thea on 06/03/2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper{

    public static final String SCHEMA = "food";
    public static final int VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, SCHEMA, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //if the db exists, it will not call onCreate
        //id the db does not exist, it will call onCreate
        //create tables here

        //CREATE TABLE tablename
        /*
        CREATE TABLE food (idfood INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL);
         */

        String sql = "CREATE TABLE " + Food.TABLE + "( " + Food.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Food.COLUMN_NAME + " TEXT NOT NULL, "
                + Food.COLUMN_PRICE +  " REAL NOT NULL);";

        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //will be called when device's version < new apk's version
        //drop table
        //DROP TABLE IF EXISTS food
        String sql = "DROP TABLE IF EXISTS + " + Food.TABLE;
        db.execSQL(sql);

        //onCreate
        onCreate(db);

    }

    //CRUD Operators here

    //create food
    public long createFood(Food food){
        SQLiteDatabase db = getWritableDatabase();
        //INSERT INTO food('name', 'price') VALUES (?,?)

        ContentValues cv = new ContentValues();
        cv.put(Food.COLUMN_NAME, food.getName());
        cv.put(Food.COLUMN_PRICE, food.getPrice());

        long id = db.insert(Food.TABLE, null, cv);
        db.close();
        return id;
    }

    //retrieve all food
    public Cursor getAllFood(){
        //SELECT * FROM food;
        SQLiteDatabase db = getReadableDatabase();

        return db.query(Food.TABLE,
                null, // *
                null, // where clause
                null, // where args
                null, //group by
                null, //having
                null); //order by

    }

    //retrieve single food
    public Food getFood(int id){
        Food food = new Food();
        //SELECT * FROM food WHERE _id = ?
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(Food.TABLE,
                null,
                Food.COLUMN_ID + " =? ",
                new String[]{id+""},
                null,
                null,
                null);

        if(cursor.moveToFirst()){

            String name = cursor.getString(cursor.getColumnIndex(Food.COLUMN_NAME));

            double price = cursor.getDouble(cursor.getColumnIndex(Food.COLUMN_PRICE));

            food.setId(id);
            food.setName(name);
            food.setPrice(price);



        }
        cursor.close();
        db.close();

        return food;
    }

    //update food
    public int updateFood(Food food){ // returns number of rows affected
        SQLiteDatabase db = getWritableDatabase();
        /*UPDATE INTO food
        SET name = ? and price = ?
        WHERE id = ?
        */

        ContentValues cv = new ContentValues();
        cv.put(Food.COLUMN_NAME, food.getName());
        cv.put(Food.COLUMN_PRICE, food.getPrice());
        int rows = db.update(Food.TABLE, cv, Food.COLUMN_ID + " =? " , new String[]{food.getId() + ""});

        db.close();
        return rows;
    }

    //delete food
    public int deleteFood(int id){
        SQLiteDatabase db = getWritableDatabase();

        //DELETE FROM food Where _id = ?;

        int rows = db.delete(Food.TABLE, Food.COLUMN_ID + "=?", new String[]{id+""});
        db.close();
        return rows;

    }

}
