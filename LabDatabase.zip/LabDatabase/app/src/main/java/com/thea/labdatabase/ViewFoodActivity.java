package com.thea.labdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ViewFoodActivity extends AppCompatActivity {
    TextView tvId, tvName, tvPrice;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_food);

        tvId = (TextView) findViewById(R.id.tv_id);
        tvName = (TextView) findViewById(R.id.tv_name);
        tvPrice = (TextView) findViewById(R.id.tv_price);
        Log.i("hi: ", "hi");

        int id = getIntent().getIntExtra(Food.COLUMN_ID, -1);
        if(id != -1){
            dbHelper = new DatabaseHelper(getBaseContext());
            Food food = dbHelper.getFood(id);
            Log.i("food id: ", food.getId() + "");
            Log.i("food name: ", food.getName() + "");
            Log.i("food price: ", food.getPrice() + "");

            tvId.setText(food.getId() + "");
            tvName.setText(food.getName());
            tvPrice.setText(food.getPrice() + "");
        }

    }
}
